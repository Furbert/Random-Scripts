create function is_main_table(schema_name name, table_name name) returns boolean
    stable
    language sql
as
$$
SELECT EXISTS(
         SELECT 1 FROM _timescaledb_catalog.hypertable h
         WHERE h.schema_name = is_main_table.schema_name AND 
               h.table_name = is_main_table.table_name
     );
$$;

alter function is_main_table(name, name) owner to postgres;

