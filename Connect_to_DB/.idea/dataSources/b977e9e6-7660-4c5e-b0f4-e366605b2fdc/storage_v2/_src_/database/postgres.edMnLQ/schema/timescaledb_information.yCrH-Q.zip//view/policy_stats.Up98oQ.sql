create view policy_stats(hypertable, job_id, job_type, last_run_success, last_finish, last_start, next_start,
                         total_runs, total_failures) as
SELECT (format('%1$I.%2$I'::text, ht.schema_name, ht.table_name))::regclass AS hypertable,
       p.job_id,
       j.job_type,
       js.last_run_success,
       js.last_finish,
       js.last_start,
       js.next_start,
       js.total_runs,
       js.total_failures
FROM ((((SELECT bgw_policy_reorder.job_id,
                bgw_policy_reorder.hypertable_id
         FROM _timescaledb_config.bgw_policy_reorder
         UNION
         SELECT bgw_policy_drop_chunks.job_id,
                bgw_policy_drop_chunks.hypertable_id
         FROM _timescaledb_config.bgw_policy_drop_chunks) p
    JOIN _timescaledb_catalog.hypertable ht ON ((p.hypertable_id = ht.id)))
    JOIN _timescaledb_config.bgw_job j ON ((p.job_id = j.id)))
         JOIN _timescaledb_internal.bgw_job_stat js ON ((p.job_id = js.job_id)))
ORDER BY ht.schema_name, ht.table_name;

alter table policy_stats
    owner to postgres;

