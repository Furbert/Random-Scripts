create view continuous_aggregates(view_name, view_owner, refresh_lag, refresh_interval, max_interval_per_job,
                                  materialization_hypertable, view_definition) as
SELECT (format('%1$I.%2$I'::text, cagg.user_view_schema, cagg.user_view_name))::regclass AS view_name,
       viewinfo.viewowner                                                                AS view_owner,
       CASE _timescaledb_internal.get_time_type(cagg.raw_hypertable_id)
           WHEN 'timestamp without time zone'::regtype THEN (_timescaledb_internal.to_interval(cagg.refresh_lag))::text
           WHEN 'timestamp with time zone'::regtype THEN (_timescaledb_internal.to_interval(cagg.refresh_lag))::text
           WHEN 'date'::regtype THEN (_timescaledb_internal.to_interval(cagg.refresh_lag))::text
           ELSE (cagg.refresh_lag)::text
           END                                                                           AS refresh_lag,
       bgwjob.schedule_interval                                                          AS refresh_interval,
       CASE _timescaledb_internal.get_time_type(cagg.raw_hypertable_id)
           WHEN 'timestamp without time zone'::regtype
               THEN (_timescaledb_internal.to_interval(cagg.max_interval_per_job))::text
           WHEN 'timestamp with time zone'::regtype THEN (_timescaledb_internal.to_interval(cagg.max_interval_per_job))::text
           WHEN 'date'::regtype THEN (_timescaledb_internal.to_interval(cagg.max_interval_per_job))::text
           ELSE (cagg.max_interval_per_job)::text
           END                                                                           AS max_interval_per_job,
       (format('%1$I.%2$I'::text, ht.schema_name, ht.table_name))::regclass              AS materialization_hypertable,
       directview.viewdefinition                                                         AS view_definition
FROM _timescaledb_catalog.continuous_agg cagg,
     _timescaledb_catalog.hypertable ht,
     LATERAL ( SELECT c.oid,
                      pg_get_userbyid(c.relowner) AS viewowner
               FROM (pg_class c
                        LEFT JOIN pg_namespace n ON ((n.oid = c.relnamespace)))
               WHERE ((c.relkind = 'v'::"char") AND (c.relname = cagg.user_view_name) AND
                      (n.nspname = cagg.user_view_schema))) viewinfo,
     LATERAL ( SELECT bgw_job.schedule_interval
               FROM _timescaledb_config.bgw_job
               WHERE (bgw_job.id = cagg.job_id)) bgwjob,
     LATERAL ( SELECT pg_get_viewdef(c.oid) AS viewdefinition
               FROM (pg_class c
                        LEFT JOIN pg_namespace n ON ((n.oid = c.relnamespace)))
               WHERE ((c.relkind = 'v'::"char") AND (c.relname = cagg.direct_view_name) AND
                      (n.nspname = cagg.direct_view_schema))) directview
WHERE (cagg.mat_hypertable_id = ht.id);

alter table continuous_aggregates
    owner to postgres;

