create function is_main_table(table_oid regclass) returns boolean
    stable
    language sql
as
$$
SELECT EXISTS(SELECT 1 FROM _timescaledb_catalog.hypertable WHERE table_name = relname AND schema_name = nspname)
    FROM pg_class c
    INNER JOIN pg_namespace n ON (n.OID = c.relnamespace)
    WHERE c.OID = table_oid;
$$;

alter function is_main_table(regclass) owner to postgres;

