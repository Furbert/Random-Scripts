create function partitioning_column_to_pretty(d _timescaledb_catalog.dimension) returns text
    stable
    strict
    language plpgsql
as
$$
DECLARE
BEGIN
        IF d.partitioning_func IS NULL THEN
           RETURN d.column_name;
        ELSE
           RETURN format('%I.%I(%I)', d.partitioning_func_schema, d.partitioning_func, d.column_name);
        END IF;
END
$$;

alter function partitioning_column_to_pretty(_timescaledb_catalog.dimension) owner to postgres;

