create view hypertable(table_schema, table_name, table_owner, num_dimensions, num_chunks, table_size, index_size,
                       toast_size, total_size) as
SELECT ht.schema_name                     AS table_schema,
       ht.table_name,
       t.tableowner                       AS table_owner,
       ht.num_dimensions,
       (SELECT count(1) AS count
        FROM _timescaledb_catalog.chunk ch
        WHERE (ch.hypertable_id = ht.id)) AS num_chunks,
       size.table_size,
       size.index_size,
       size.toast_size,
       size.total_size
FROM ((_timescaledb_catalog.hypertable ht
    LEFT JOIN pg_tables t ON (((ht.table_name = t.tablename) AND (ht.schema_name = t.schemaname))))
         LEFT JOIN LATERAL hypertable_relation_size_pretty((
    CASE
        WHEN has_schema_privilege((ht.schema_name)::text, 'USAGE'::text)
            THEN format('%I.%I'::text, ht.schema_name, ht.table_name)
        ELSE NULL::text
        END)::regclass) size(table_size, index_size, toast_size, total_size) ON (true));

alter table hypertable
    owner to postgres;

