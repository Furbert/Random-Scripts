create function timescaledb_post_restore() returns boolean
    language plpgsql
as
$fun$
DECLARE 
    db text; 
BEGIN
    SELECT current_database() INTO db;
    EXECUTE format($$ALTER DATABASE %I SET timescaledb.restoring ='off'$$, db);
    SET SESSION timescaledb.restoring='off';
    PERFORM _timescaledb_internal.start_background_workers();
    RETURN true;
END
$fun$;

alter function timescaledb_post_restore() owner to postgres;

